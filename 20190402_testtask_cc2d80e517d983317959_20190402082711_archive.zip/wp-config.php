<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'testtask');

/** Имя пользователя MySQL */
define('DB_USER', 'testtask');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'testtask');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '|`AtFQJOSRec7?Q`}M-zbLTE5q]]kQj9PScV~E{VK>@drZ7rv[WHi>nk1-?l<(UH');
define('SECURE_AUTH_KEY',  'p_aq~Clo$C-n?&J6$H!VPZ_oB,~AI~ {%:fZ6L!@b.->+{a%m>X!w[,0H||Ka0v.');
define('LOGGED_IN_KEY',    ';!^fBq;1 hHzLK9}4tyq7<M8u|ffN619dsr&HQzv<&XTjRln`FL~M5hu6i(]`TW1');
define('NONCE_KEY',        '2MzzOE{>5u,/]q}dVv#n53rc]*$AtZJ~MuM*01!x~eaQD<5B^g3@ltLz`kjGjN,l');
define('AUTH_SALT',        'R?z j8OAs:t8p:|GtAIO(_A(4C}~R(;I5UzQ4FbpRxx-$%} 17WLY<Oz8;< jRy0');
define('SECURE_AUTH_SALT', 'Qc*iKS3=$?Cd#|u/UjC?%M6e_nGz={!Pa2.4}pwB?eoRT8W]=Yjfn,89}N8Rpl<c');
define('LOGGED_IN_SALT',   'UBkQHg4po`>ty;03<CQvX*$YHx|HA<4aXk7,)d(suTJ{ARCXYF4c{;7%BI=+@TB?');
define('NONCE_SALT',       'M;Kh.}PfL|ZvDaMOjaA]e3%?Ky|1/sWrVWlh_1p1uA.P&#_&q:{_X,J1]b<d*R&W');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
